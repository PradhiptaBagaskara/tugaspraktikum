<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
  <title>Tugas Ganteng</title>
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <style type="text/css">
    .jarak {
      padding-top: 200px;
      padding-left: 200px;
      padding-right: auto;
    }
    .card {
      margin: auto;
    }
    .get{
      margin-left: 80px;
    }
  </style>

</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">

</nav>

<div class="container jarak">
    <div class="col-sm-9">
<div class="card border-success mb-3 " style="max-width: 18rem;">
  <div class="card-header">Pesanan Anda</div>
  <div class="card-body text-success">
    <p><?=$_GET['makanan']?> (<?=$_GET['jumlahmakanan']?>)</p>
    <p><?=$_GET['minuman']?> (<?=$_GET['jumlahminuman']?>)</p>



  </div>
</div>
</div>


</div>

<script src="assets/js/jquery.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>