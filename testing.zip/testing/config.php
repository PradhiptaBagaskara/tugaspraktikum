<?php 

// url projek
$url 	= "http://localhost/testing/";




// makanan dan minuman list, ganti sesuai keindahan surga duniamu

$makanan     = array('soto','sate','gule' );
$minuman     = array('Es Teh', 'Es Jeruk', 'Es Degan' );

// array untuk perulangan JANGAN DIGANTI
$nomer       = 1;
$menu        =  array('makanan' => $makanan, 'minuman' => $minuman );

// echo json_encode($menu);  
                 
   








 ?>