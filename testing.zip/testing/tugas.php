<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title>Tugas Ganteng</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <style type="text/css">
    .jarak{
      margin-top: 100px;
    }
  </style>

</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Home</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link active" href="#">Beranda <span class="sr-only"></span></a>
      <a class="nav-item nav-link" href="#">Pembelian</a>
      <a class="nav-item nav-link" href="#">Kategori</a>
    </div>
  </div>
</nav>





<div class="container jarak">


  <div class="row">
    <div class="col-sm-9">
        <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Menu</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($menu as $mkn ): ?>
      <?php foreach ($mkn as $key): ?>

          <tr>
      <th scope="row"><?=$nomer++?></th>
      <td><?=$key?></td>
    </tr>
        
      <?php endforeach ?>

  
      
    <?php endforeach ?>
    

  </tbody>
</table>
        
    </div>
    <div class="col-md6">
        <div class="card bg-light mb-3" style="max-width: 18rem;">
           <div class="card-header">ChekOut</div>
  <div class="card-body">

    <?php 

    if ($_GET['method'] == 'post') 
    {
    echo '<form method="post" action="post.php">'; 
    } 
    
    elseif ($_GET['method'] == 'get')
    { 
    echo '<form method="get" action="get.php">';  
    } 
  
    else { 
    header('location: index.php'); 
    } 
    ?> 
      


  <div class="form-group">
     <label for="makanan">Makanan</label>
    <select class="form-control" id="makanan" name="makanan" >
     <?php foreach ($menu['makanan'] as $makan): ?>

     <option value="<?=$makan?>"><?=$makan?></option>
       
     <?php endforeach ?>
     
    </select>
  </div>
  <div class="form-group">
    <label for="jumalahmakan">Jumlah Makanan</label>
    <select class="form-control" id="jumalahmakan" name="jumlahmakanan" >
      <?php for ($i=1; $i <= 100 ; $i++): ?>
      <option value="<?=$i?>"><?=$i?></option>
      <?php endfor; ?>
    </select>
  </div>
  <div class="form-group">
     <label for="minuman">minuman</label>
    <select class="form-control" id="makanan" name="minuman" >
      <?php foreach ($menu['minuman'] as $minum): ?>

     <option value="<?=$minum?>"><?=$minum?></option>
       
     <?php endforeach ?>
    </select>
  </div>
  <div class="form-group">
    <label for="jumlahminum">Jumlah minuman</label>
    <select class="form-control" id="jumlahminum" name="jumlahminuman" >
       <?php for ($i=1; $i <= 100 ; $i++): ?>
      <option value="<?=$i?>"><?=$i?></option>
      <?php endfor; ?>
    </select>
  </div>

  <button type="submit" class="btn btn-primary">Pesan</button>
</form>
    </div>
  </div>

  
</div>
      
    </div>
  </div>


</div>


<script src="assets/js/jquery.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>